VARIABLES
---------

List of variables defined in the current directory.

This read-only property specifies the list of CMake variables
currently defined.  It is intended for debugging purposes.
