ADVANCED
--------

True if entry should be hidden by default in GUIs.

This is a boolean value indicating whether the entry is considered
interesting only for advanced configuration.  The :command:`mark_as_advanced`
command modifies this property.
