elseif
------

Starts an elseif portion of an if block.

.. code-block:: cmake

  elseif(<condition>)

See the :command:`if` command, especially for the syntax and logic
of the ``<condition>``.
